from django.urls import path
from . import views

app_name = 'booking'

urlpatterns = [
    path('', views.event_list, name='event_list'),
    path('select_seats/<int:event_id>/', views.select_seats, name='select_seats'),
    path('confirm/<str:bookingid>/', views.confirm_booking, name='confirm_booking'),
    path('booking_history/', views.booking_history, name='booking_history'),
    # ❌ REMOVED: path('login/', views.custom_login, name='login'),
]
