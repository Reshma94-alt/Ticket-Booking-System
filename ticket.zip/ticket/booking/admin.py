from django.contrib import admin
from .models import Event, Booking

@admin.register(Event)
class EventAdmin(admin.ModelAdmin):
    list_display = ['name', 'date', 'venue', 'available_seats', 'price']
    list_filter = ['date']
    search_fields = ['name', 'venue']

@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ['booking_id', 'user', 'event', 'seats_booked', 'total_amount']
    list_filter = ['booking_date']
    search_fields = ['booking_id', 'user__username']
