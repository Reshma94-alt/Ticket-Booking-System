from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Event, Booking
from .forms import BookingForm

def event_list(request):
    """Display all available events"""
    events = Event.objects.all()
    return render(request, 'booking/event_list.html', {'events': events})  # ✅ FIXED PATH

@login_required
def select_seats(request, event_id):
    """Select seats and create booking"""
    event = get_object_or_404(Event, id=event_id)
    form = BookingForm()
    
    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            seats = form.cleaned_data['seats']
            
            # Check available seats
            if seats > event.available_seats:
                form.add_error('seats', f'Only {event.available_seats} seats available')
            else:
                # Create booking
                booking = Booking.objects.create(
                    user=request.user,
                    event=event,
                    seats_booked=seats,
                    total_amount=seats * event.price
                )
                
                # Update available seats
                event.available_seats -= seats
                event.save()
                
                messages.success(request, f'Booking created! ID: {booking.id}')
                return redirect('booking:confirm_booking', bookingid=booking.id)  # ✅ Use .id
    
    return render(request, 'booking/select_seats.html', {  # ✅ FIXED PATH
        'event': event, 
        'form': form,
        'max_seats': event.available_seats
    })

@login_required
def confirm_booking(request, bookingid):
    """Confirm payment and complete booking"""
    booking = get_object_or_404(Booking, id=bookingid, user=request.user)  # ✅ Use .id
    
    if request.method == 'POST':
        messages.success(request, f'✅ Payment successful! Booking {booking.id} CONFIRMED')
        return redirect('booking:booking_history')
    
    return render(request, 'booking/confirm_booking.html', {'booking': booking})  # ✅ FIXED PATH

@login_required
def booking_history(request):
    """Show user's booking history"""
    bookings = Booking.objects.filter(user=request.user).order_by('-booking_date')
    return render(request, 'booking/booking_history.html', {'bookings': bookings})  # ✅ FIXED PATH
