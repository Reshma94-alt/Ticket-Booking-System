from django.db import models
from django.contrib.auth.models import User
import uuid

class Event(models.Model):
    name = models.CharField(max_length=100)
    date = models.DateField()
    venue = models.CharField(max_length=100)
    totalseats = models.IntegerField(default=100)
    available_seats = models.IntegerField(default=100)  # ✅ Snake_case
    price = models.DecimalField(max_digits=8, decimal_places=2)

    def __str__(self):
        return self.name

class Booking(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    event = models.ForeignKey(Event, on_delete=models.CASCADE)
    seats_booked = models.IntegerField()  # ✅ Snake_case
    total_amount = models.DecimalField(max_digits=8, decimal_places=2)  # ✅ Snake_case
    booking_date = models.DateTimeField(auto_now_add=True)  # ✅ Snake_case
    booking_id = models.CharField(max_length=20, unique=True, blank=True)  # ✅ Snake_case

    def save(self, *args, **kwargs):
        if not self.booking_id:
            self.booking_id = str(uuid.uuid4())[:8].upper()
        super().save(*args, **kwargs)

    def __str__(self):
        return f'{self.user.username} - {self.event.name}'
