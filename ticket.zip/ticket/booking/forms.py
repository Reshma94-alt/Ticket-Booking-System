from django import forms

class BookingForm(forms.Form):
    seats = forms.IntegerField(min_value=1, max_value=10, label='Number of Seats')
